# আলোর পথ — Android Studio প্রজেক্ট

এটি v10 ওয়েব অ্যাপের Android WebView wrapper প্রজেক্ট। মূল অ্যাপের ফাইলগুলো `app/src/main/assets/`-এ রাখা হয়েছে।

## APK বানানোর নিয়ম
1. কম্পিউটারে Android Studio (সাম্প্রতিক সংস্করণ) ইনস্টল করুন।
2. Android Studio থেকে **Open** নির্বাচন করে এই প্রজেক্টের `AlorPothAndroid` ফোল্ডার খুলুন।
3. Gradle sync শেষ হলে **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপুন।
4. APK পাওয়া যাবে: `app/build/outputs/apk/debug/app-debug.apk`

## বৈশিষ্ট্য
- অ্যাপটি ইন্টারনেট ছাড়াই bundled assets থেকে চালু হয়।
- JavaScript ও local storage চালু আছে; IndexedDB-তে রাখা ব্যক্তিগত ফাইল ডিভাইসেই থাকে।
- WebView file chooser যুক্ত, তাই “আমার ফাইল” থেকে ডিভাইসের ফাইল নির্বাচন করা যায়।

## নোট
এই পরিবেশে Android SDK/Gradle build toolchain নেই, তাই এখানে APK binary compile করা হয়নি। Android Studio দিয়ে উপরের ধাপগুলো অনুসরণ করে APK তৈরি করতে হবে। Play Store-এ প্রকাশের জন্য আলাদা release signing ও নীতিমালা পূরণ প্রয়োজন।
