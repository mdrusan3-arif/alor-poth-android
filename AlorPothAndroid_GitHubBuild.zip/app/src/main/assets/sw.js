const CACHE='alor-poth-v10';
const FILES=['./','./index.html','./manifest.webmanifest','./assets/icon.svg','./assets/books/islamer-mool-porichoy.pdf','./assets/books/ইসলামের-মূল-পরিচয়-খসড়া.docx','./assets/references/prayer-guide.pdf','./assets/references/fajr-after-prayer.pdf','./assets/references/short-surahs-bn.pdf'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>Promise.all(FILES.map(f=>c.add(f).catch(()=>{})))))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  if(r.mode==='navigate'){
    e.respondWith(fetch(r).then(res=>{if(res.ok){const c=res.clone();caches.open(CACHE).then(x=>x.put('./index.html',c)).catch(()=>{})}return res}).catch(()=>caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{if(res.ok&&res.status===200){const c=res.clone();caches.open(CACHE).then(x=>x.put(r,c)).catch(()=>{})}return res})));
});
